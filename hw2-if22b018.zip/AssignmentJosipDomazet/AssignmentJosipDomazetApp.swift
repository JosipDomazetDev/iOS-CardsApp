//
//  AssignmentJosipDomazetApp.swift
//  AssignmentJosipDomazet
//
//  Created by user on 22.09.23.
//

import SwiftUI

@main
struct AssignmentJosipDomazetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(viewModel: CardViewModel(repository: CardRepository()))
        }
    }
}
